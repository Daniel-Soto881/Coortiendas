<?php
echo . $idProd ."";
?>